<?php $this->view('header')?>
    <link rel="stylesheet" type="text/css" href="<?=ROOT?>/assets/home-page/assets/css/styles.css">

    <div class="class_13" style="color: #222;">
        <h1 class="class_11">
            <br>
            Thank you for your Order!
            <br>
        </h1>
    </div>

<?php $this->view('footer')?>
