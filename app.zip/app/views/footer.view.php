<style>
	
.footer_1{

	padding: 20px;
	background-color: rgb(63, 63, 63);
	color: rgb(255, 255, 255);
	display: flex;
	justify-content: space-around;
	flex-wrap: wrap;
	
}

.footer_2{

	padding: 10px;
	 color: rgb(255, 255, 255);
	min-width: 300px;
	margin-top: 2px;
	margin-bottom: 2px;
	
}

.footer_3{

	color: rgb(255, 255, 255);
	display: block;
	margin-top: 8px;
	
}

</style>
	<div class="footer_1" >
		<div class="footer_2" >
			<a href="<?=ROOT?>/login" class="footer_3"  >
				Login
			</a>
			<a href="<?=ROOT?>/signup" class="footer_3"  >
				Signup
			</a>
			<a href="<?=ROOT?>/shop" class="footer_3"  >
				Shop
			</a>
		</div>
		<div class="footer_2" >
			<a href="#" class="footer_3"  >
				Terms &amp; conditions
			</a>
			<a href="#" class="footer_3"  >
				Terms of use
			</a>
			<a href="<?=ROOT?>/logout" class="footer_3"  >
				Logout
			</a>
		</div>
		<div class="footer_2" >
			<a href="#" class="footer_3"  >
				Login
			</a>
			<a href="#" class="footer_3"  >
				Signup
			</a>
			<a href="#" class="footer_3"  >
				Shop
			</a>
		</div>
		<div class="footer_2" >
			<a href="#" class="footer_3"  >
				Login
			</a>
			<a href="#" class="footer_3"  >
				Signup
			</a>
			<a href="<?=ROOT?>/admin" class="footer_3"  >
				Admin
			</a>
		</div>
	</div>
	

</body>
</html>