<?php $this->view('admin/admin.header')?>

	<div class="class_14" >
		<div class="class_15" >
			<i  class="bi bi-person-fill-gear class_16">
			</i>
			<h1 class="class_17"  >
				8
				<br >
			</h1>
			<h1 class="class_18"  >
				Admins
			</h1>
		</div>
		<div class="class_15" >
			<i  class="bi bi-people class_16">
			</i>
			<h1 class="class_17"  >
				1,000
			</h1>
			<h1 class="class_18"  >
				Users
				<br >
			</h1>
		</div>
		<div class="class_15" >
			<i  class="bi bi-file-post class_16">
			</i>
			<h1 class="class_17"  >
				874
			</h1>
			<h1 class="class_18"  >
				Products
			</h1>
		</div>
		<div class="class_15" >
			<i  class="bi bi-stickies-fill class_16">
			</i>
			<h1 class="class_17"  >
				564
			</h1>
			<h1 class="class_18"  >
				Pages
			</h1>
		</div>
	</div>
		

<?php $this->view('admin/admin.footer')?>