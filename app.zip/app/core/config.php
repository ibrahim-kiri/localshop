<?php 

defined('ROOTPATH') OR exit('Access Denied!');

if($_SERVER['SERVER_NAME'] == 'localhost')
{
	/** database config **/
	define('DBNAME', 'localshop_db');
	define('DBHOST', 'localhost');
	define('DBUSER', 'root');
	define('DBPASS', '');
	define('DBDRIVER', 'mysql');
	
	define('ROOT', 'http://localhost/localshop/public');

}else
{
	/** database config **/
	define('DBNAME', 'id21042581_localshop_db');
	define('DBHOST', 'localhost');
	define('DBUSER', 'id21042581_mylocalroot');
	define('DBPASS', 'Vvu&RX0hW-McE}X%');
	define('DBDRIVER', 'mysql');

	define('ROOT', 'https://perambulatory-cushi.000webhostapp.com/');

}

define('APP_NAME', "Local Shop");
define('APP_DESC', "Best website on the planet");

/** true means show errors **/
define('DEBUG', true);
